print("This is just a test")
