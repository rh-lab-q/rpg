from rpg.plugin import Plugin


class TestPlugin(Plugin):

    def extracted(self, project_dir, spec, sack):
        pass
