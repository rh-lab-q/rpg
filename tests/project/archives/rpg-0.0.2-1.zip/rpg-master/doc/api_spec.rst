Spec module
===========

.. automodule:: spec
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
