.. rpg documentation master file, created by
   sphinx-quickstart on Sun Jul  5 10:15:43 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to rpg's documentation!
===============================

.. warning::

	RPG is in alpha stage and the docs could change at any time without any notice

Contents:

.. toctree::
   :maxdepth: 1

   command_ref
   writing_plugins
   api_base
   api_command
   api_plugin
   api_spec

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
