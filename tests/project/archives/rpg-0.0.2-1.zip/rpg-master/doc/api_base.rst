Base class
==========

.. autoclass:: __init__.Base
    :members:
    :undoc-members:
