Plugin class
============

.. autoclass:: rpg.plugin.Plugin
    :members:
    :undoc-members:
