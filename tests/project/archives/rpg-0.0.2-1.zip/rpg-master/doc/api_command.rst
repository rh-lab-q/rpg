Command module
==============

.. automodule:: rpg.command
    :members:
    :undoc-members:
