#include <sqlite3.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
    return 0;
}
