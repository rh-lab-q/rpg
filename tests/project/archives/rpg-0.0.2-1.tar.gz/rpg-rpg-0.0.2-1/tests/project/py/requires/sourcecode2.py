import math


class A:
    pass
