import rpg


class A:
    pass
