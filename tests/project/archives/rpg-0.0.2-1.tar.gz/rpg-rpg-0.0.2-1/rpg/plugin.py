class Plugin:

    """class from which are plugins derived"""

    # def extracted(self, project_dir, spec, sack):
    #     # :api
    #     pass

    # def patched(self, project_dir, spec, sack):
    #     # :api
    #     pass

    # def compiled(self, project_dir, spec, sack):
    #     # :api
    #     pass

    # def installed(self, project_dir, spec, sack):
    #     # :api
    #     pass

    # def package_build(self, package_path, spec, sack):
    #     # :api
    #     pass
